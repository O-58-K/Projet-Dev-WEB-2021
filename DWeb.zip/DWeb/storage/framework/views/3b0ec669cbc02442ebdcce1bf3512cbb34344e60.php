

<?php $__env->startSection('contenu'); ?>

<section class="resume-section d-flex justify-content-center" id="">
        <div class="w-100">
        <?php
          $pdo = new PDO("mysql:host=localhost;dbname=projetweb", "root", "", array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));

          $result = $pdo->query("SELECT * FROM annonces WHERE id "); 
              while ($annonces = $result->fetch(PDO::FETCH_OBJ)) { ?>
           
           <div class="grid_1_of_3 images_1_of_3">
						<div class="grid_1">
						    <img style="width: 100%; margin-top: 7%;" src="<?php echo $annonces->Photo; ?>" title="continue reading" alt="">
                            <div style="text-align: center; background: lightgrey;" class="grid_desc">
                                <br>
                            <h5 class="card-title">ID : <?php echo $annonces->id; ?></h5>
                            <h2 class="card-title"><?php echo $annonces->Titre; ?></h2>
                            <br><h5 class="js-scroll-trigger" style="font-weight: bold;"> Description</h5>
                            <p><?php echo $annonces->Description; ?></p>
                            <br><h5 class="js-scroll-trigger" style="font-weight: bold;"> Ville</h5>
                            <p><?php echo $annonces->Ville; ?></p>
                            <br><h5 class="js-scroll-trigger" style="font-weight: bold;"> Date</h5>
                            <p><?php echo $annonces->Date; ?></p>
                            <br>
                            <span class="reducedfrom"><?php echo $annonces->Prix . "€"; ?></span>
                            <br><br>
                            <center>
                                <div class="card">
                                <h5><?php echo $annonces->Statut; ?></h5> 
                                </div>
                            </center>
                            <div class="cart-button">                         
                            <div class="clear"></div>
                            </div>
					        </div>
                        </div>
                <div class="clear"></div>
          </div>

              <?php } ?>

    </div>
  </section>

  <br><br><br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Okan\Desktop\Projet Dev Web\DWeb\resources\views/Accueil.blade.php ENDPATH**/ ?>