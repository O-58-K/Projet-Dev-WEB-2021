

<?php $__env->startSection('contenu'); ?>
    <ul>
        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e(var_dump($games)); ?>


            <li><a href="<?php echo e(url("game/{$game->id}")); ?>"> <?php echo e($game->name); ?> </a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Okan\Desktop\Projet Dev Web\DWeb\resources\views//games.blade.php ENDPATH**/ ?>