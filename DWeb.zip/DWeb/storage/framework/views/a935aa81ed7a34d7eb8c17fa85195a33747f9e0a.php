

<?php $__env->startSection('contenu'); ?>

<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <a href="jeu?id=2764"><img style="height:300px;" class="d-block w-100" src="https://i.redd.it/c80pgq3hee331.jpg" alt="First slide"></a>
    </div>
    <div class="carousel-item">
    <a href="jeu?id=2770"><img style="height:300px;" class="d-block w-100" src="https://s1.thcdn.com/widgets/96-fr/48/OVERWATCH-top-banner-012548.jpg" alt="Second slide"></a>
    </div>
    <div style="height:300px;" class="carousel-item">
    <a href="jeu?id=2769"><img class="d-block w-100" src="https://www.amd.com/system/files/2020-07/530171-Assassins-Creed-Valhalla-key-banner-fade-1920x600.jpg" alt="Third slide"></a>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<section class="resume-section d-flex justify-content-center" id="">
        <div class="w-100">
        <?php
          $pdo = new PDO("mysql:host=localhost;dbname=projetweb", "root", "", array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));

          $result = $pdo->query("SELECT * FROM annonces WHERE id "); 
              while ($annonces = $result->fetch(PDO::FETCH_OBJ)) { ?>
           
           <div class="grid_1_of_3 images_1_of_3">
						<div class="grid_1">
						    <img style="width: 100%; margin-top: 7%;" src="<?php echo $annonces->Photo; ?>" title="continue reading" alt="">
                            <div style="text-align: center; background: mediumpurple;" class="grid_desc">
                                <br>
                            <h2 style="background: mediumpurple;" class="card-title"><?php echo $annonces->Titre; ?></h2>
                            <center>
                                <div style="background: mediumpurple;" class="card">
                                <br>
                                <h5 style="background: mediumpurple;"><a style="float: left ; margin-left: 50px; width: 20%;" href="jeu?id=<?php echo $annonces->id; ?>" class="btn btn-outline-light">Voir en détail</a><a style="float: right ; margin-right: 50px;  width: 21%;" href="panier?id=<?php echo $annonces->id; ?>" class="btn btn-outline-light">Ajouter au panier</a></h5> 
                                <br>
                                </div>
                            </center>
                            <div class="cart-button">                         
                            <div class="clear"></div>
                            </div>
					        </div>
                        </div>
                <div class="clear"></div>
          </div>

              <?php } ?>

    </div>
  </section>

    

  <br><br><br><br><br><br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Okan\Desktop\Projet Dev Web\DWeb\resources\views//Accueil.blade.php ENDPATH**/ ?>