


<?php $__env->startSection('contenu'); ?>
    <section class="resume-section d-flex justify-content-center" id="experience">
          <div class="w-100">

            <?php
              $pdo = new PDO("mysql:host=localhost;dbname=projetweb", "root", "", array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));

              //******************************************* */
              $result = $pdo->query("SELECT * FROM annonces WHERE id = $_GET[id]");
              $annonces = $result->fetch(PDO::FETCH_OBJ);
              //******************************************* */
            ?>   
              <div class="grid_1_of_3 images_1_of_3">
                      <div class="grid_1">
                        <img style="width: 100%; margin-top: 7%;" src="<?php echo $annonces->Photo; ?>" title="continue reading" alt="">
                          <div style="text-align: center; background: mediumpurple;" class="grid_desc">
                            <br>
                              <h2 style="background: mediumpurple;" class="card-title"><?php echo $annonces->Titre; ?></h2>
                              <br><h5 class="js-scroll-trigger" style="font-weight: bold;"> Description</h5>
                              <p><?php echo $annonces->Description; ?></p>
                              <br>
                              <h2 class="reducedfrom"><?php echo $annonces->Prix . "€"; ?></h2>
                              <br><br>
                              <center>
                                <div style="background: mediumpurple;" class="card">
                                <br>
                                <h5 style="background: mediumpurple;"><a style="width: 40%; margin-bottom: 10px;" href="panier?id=<?php echo $annonces->id; ?>" class="btn btn-outline-light">Ajouter au panier</a></h5> 
                                </div>
                              </center>
                              <div class="cart-button">
                                
                                <div class="clear"></div>
                            </div>
                          </div>
                    </div>
                      <div class="clear"></div>
              </div>
                    

      </div>
    </section>

    <br><br><br><br><br><br>

                  <div class="grid_1_of_3 images_1_of_3">
                  <div class="grid_1">
                              <div style="text-align: center; background: mediumpurple;" class="grid_desc">
                                <br>
                                  <h1>Commentaires : </h1>
                                    <br>
                                  <h3 style="background: mediumpurple;" class="card-title"><?php echo $annonces->commentaires; ?></h3>
                                  <div class="cart-button">                         
                                  <div class="clear"></div>
                                  <br><br>
                              </div>
                      </div>
                            </div>
                    <div class="clear"></div>
                  </div>

   
                  <br><br><br><br><br><br>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Okan\Desktop\Projet Dev Web\DWeb\resources\views/jeu.blade.php ENDPATH**/ ?>