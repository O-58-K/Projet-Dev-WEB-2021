

<?php $__env->startSection('contenu'); ?>
<div id="login">
    <br>    
    <div class="container">
        <div id="login-row" class="row justify-content-center align-items-center">
            <div id="login-column" class="col-md-6">
                <div id="login-box" class="col-md-12">
                    <form id="login-form" class="form" action="/admin" method="post">
                        <?php echo e(csrf_field()); ?>

                        <br>
                        <h3 style="color: white !important;" class="text-center text-info">Connectez-vous !</h3>
                        <div class="form-group">
                            <label style="color: white !important;" for="email" class="text-info">Email:</label><br>
                            <input type="email" name="email" id="email" class="form-control">
                        </div>
                        <div class="form-group">
                            <label style="color: white !important;" for="password" class="text-info">Mot de passe:</label><br>
                            <input type="password" name="password" id="password" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="submit" name="submit" class="btn btn-outline-light btn-md" value="Valider">
                        </div>
                        <div id="register-link" class="text-right">
                        
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Okan\Desktop\Projet Dev Web\DWeb\resources\views/admin.blade.php ENDPATH**/ ?>