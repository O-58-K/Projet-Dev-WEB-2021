

<?php $__env->startSection('content'); ?>

<div id="register">
    <h3 class="text-center text-white pt-5">Formulaire d'inscription</h3>
    <div class="container">
        <div id="register-row" class="row justify-content-center align-items-center">
            <div id="register-column" class="col-md-6">
                <div id="register-box" class="col-md-12">
                    <form id="register-form" class="form" action="/inscription" method="post">
                        <?php echo e(csrf_field()); ?>

                        <br>
                        <div class="form-group">
                            <label style="color: white !important;" for="email" class="text-info">Email:</label><br>
                            <input type="email" name="email" id="email" class="form-control">
                        </div>
                        <div class="form-group">
                            <label style="color: white !important;" for="name" class="text-info">Nom:</label><br>
                            <input type="string" name="name" id="name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label style="color: white !important;" for="password" class="text-info">Mot de passe:</label><br>
                            <input type="password" name="password" id="password" class="form-control">
                        </div>
                        <div class="form-group">
                            <label style="color: white !important;" for="password_confirmation" class="text-info"> Confirmation de mot de passe:</label><br>
                            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="submit" name="submit" class="btn btn-outline-light btn-md" value="Valider">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Okan\Desktop\Projet Dev Web\DWeb\resources\views/paiement.blade.php ENDPATH**/ ?>