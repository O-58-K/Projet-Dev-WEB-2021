

<?php $__env->startSection('contenu'); ?>
    <div>
        <h1>dashboard of <?php echo e($user->email); ?> </h1>

        <p>you're well signed in</p>

        <?php if(auth()->check AND auth()->user()->id === $user->id): ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Okan\Desktop\Projet Dev Web\DWeb\resources\views/profil.blade.php ENDPATH**/ ?>