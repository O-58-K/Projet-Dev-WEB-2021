<footer style="bottom: 0; position: fixed; width: 100%; background-color: mediumpurple !important" id="sticky-footer" class="py-4 bg-dark text-white-50">
    <div class="container text-center">
      <small>Okan & Baptiste &copy; GamerPlanet</small>
    </div>
  </footer><?php /**PATH C:\Users\Okan\Desktop\Projet Dev Web\DWeb\resources\views/footer.blade.php ENDPATH**/ ?>