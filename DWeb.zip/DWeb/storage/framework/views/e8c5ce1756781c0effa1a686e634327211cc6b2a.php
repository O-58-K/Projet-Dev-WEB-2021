

<?php $__env->startSection('contenu'); ?>
    <br><br>

    
        <h3 style="font-size: 35px;" class="text-bold">Vos informations personnelles :</h3>
        <br>
        <p style="font-size: 20px; margin-left: 10px;" class="font-weight-normal">Nom : <?php echo e($user->name); ?></p>
        <p style="font-size: 20px; margin-left: 10px;" class="font-weight-normal">Prénom : <?php echo e($user->prenom); ?></p>
        <p style="font-size: 20px; margin-left: 10px;" class="font-weight-normal">Mail : <?php echo e($user->email); ?></p>
        <p style="font-size: 20px; margin-left: 10px;" class="font-weight-normal">Naissance : <?php echo e($user->naissance); ?></p>
        <p style="font-size: 20px; margin-left: 10px;" class="font-weight-normal">Solde : <?php echo e($user->solde); ?> €</p>

    <br><br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Okan\Desktop\Projet Dev Web\DWeb\resources\views//dashboard.blade.php ENDPATH**/ ?>