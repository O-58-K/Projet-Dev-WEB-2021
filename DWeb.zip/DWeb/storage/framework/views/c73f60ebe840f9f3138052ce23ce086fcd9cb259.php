


<?php $__env->startSection('contenu'); ?>
<?php
    
    $pdo = new PDO("mysql:host=localhost;dbname=projetweb", "root", "", array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));

    $articles = $pdo->query('SELECT * FROM annonces ORDER BY id DESC '); 

    if(isset($_GET['q']) AND !empty($_GET['q'])){
        $q = htmlspecialchars($_GET['q']);
        $articles = $pdo->query('SELECT * FROM annonces WHERE Titre LIKE "%'.$q.'%" ORDER BY id DESC '); 
    }

    
?>

<ul>
<?php while($artc = $articles->fetch()){ ?>

        <br> 

        <section class="resume-section d-flex justify-content-center" id="">
            <div class="w-100">
            
            <div class="grid_1_of_3 images_1_of_3">
						<div class="grid_1">
                        <img style="width: 100%; margin-top: 7%;" src="<?php echo $artc['Photo'] ?>" title="continue reading" alt="">
                            <div style="text-align: center; background: mediumpurple;" class="grid_desc">
                                <br>
                            <h2 class="card-title"><?= $artc['Titre'] ?></h2>
                            <br><h5 class="js-scroll-trigger" style="font-weight: bold;"> Description</h5>
                            <p><?= $artc['Description'] ?></p>
                            <br>
                            <span class="reducedfrom"><?= $artc['Prix'] . '€' ?></span>
                            <br><br>
                            <center>
                                <div style="background: mediumpurple;" class="card">
                                <br>
                                <h5 style="background: mediumpurple;"><?= $artc['Statut'] ?></h5> 
                                <br>
                                </div>
                            </center>
                            <div class="cart-button">                         
                            <div class="clear"></div>
                            </div>
					        </div>
                        </div>
                <div class="clear"></div>
        </div>
        </section>

<?php } ?>
</ul>

<br><br><br><br><br><br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Okan\Desktop\Projet Dev Web\DWeb\resources\views/recherche.blade.php ENDPATH**/ ?>