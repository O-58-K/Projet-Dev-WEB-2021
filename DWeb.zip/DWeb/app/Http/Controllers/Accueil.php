<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Accueil extends Controller
{
    function accueil() {
        return view('/Accueil');
    }


    function games() {
        $games = App\games::all();

        return view('Accueil', [
            'games' => $games
        ]);
    }
}
