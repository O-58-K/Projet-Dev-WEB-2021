<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ADConnexionController;


Route::get('/', 'App\Http\Controllers\Accueil@accueil' );

Route::get('/recherche', function () {
    return view('recherche');
});

Route::get('/jeu', function () {
    return view('jeu');
});

// Route::post('/admin', 'App\Http\Controllers\ADConnexionController@ADconnexion');

// Route::get('/admin', 'App\Http\Controllers\ADConnexionController@form');

Route::get('/admin', function () {
    return view('admin');
});

Route::get('/signup', function () {
    return view('signup');
});

Route::get('/inscription', 'App\Http\Controllers\InscriptionController@formulaire' );

Route::post('/inscription', 'App\Http\Controllers\InscriptionController@inscription');

Route::post('/connexion', 'App\Http\Controllers\ConnexionController@connexion');

Route::get('/connexion', 'App\Http\Controllers\ConnexionController@form');

Route::get('/users/{id}', 'App\Http\Controllers\UsersController@show')->name('Show.User');

Route::get('/users/index', 'App\Http\Controllers\UsersController@index' );

ROute::group([
    'middleware' => 'App\Http\Middleware\Auth',
], function(){
    Route::get('/password_modification', 'App\Http\Controllers\UserAccountController@form_password_modification');

    Route::post('/password_modification', 'App\Http\Controllers\UserAccountController@password_modification');

    Route::get('/dashboard', 'App\Http\Controllers\UserAccountController@dashboard');

    Route::get('/signout', 'App\Http\Controllers\UserAccountController@signout');
    
    Route::get('/news_feed', 'App\Http\Controllers\UsersController@news_feed');

    Route::get('/nouvel_utilisateur', 'App\Http\Controllers\UsersController@NouvelUtilisateur');

    Route::get('/panier', function () {
        return view('panier');
    });

    Route::get('/paniervide', function () {
        return view('paniervide');
    });

    Route::get('/paiement', function () {
        return view('paiement');
    });

});
