@extends('layout')

@section('contenu')
<br><br><br><br>
<section style="background: mediumpurple;" class="jumbotron text-center">
    <div style="background: mediumpurple;" class="container">
        <h1 style="background: mediumpurple;" class="jumbotron-heading">Votre panier</h1>
     </div>
</section>

            <?php
              $pdo = new PDO("mysql:host=localhost;dbname=projetweb", "root", "", array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));

              $result = $pdo->query("SELECT * FROM annonces WHERE id = $_GET[id]");
              $annonces = $result->fetch(PDO::FETCH_OBJ);
            ?>  

<div class="container mb-4">
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col"> </th>
                            <th style="color: white;" scope="col">Jeu</th>
                            <th style="color: white;" scope="col">Disponibilité</th>
                            <th style="color: white;" scope="col" class="text-center">Quantité</th>
                            <th style="color: white;" scope="col" class="text-right">Prix</th>
                            <th> </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="background:mediumpurple;"><img style="width: 20%;" src="<?php echo $annonces->Photo; ?>" /> </td>
                            <td style="background:mediumpurple; color: white;"><?php echo $annonces->Titre; ?></td>
                            <td style="background:mediumpurple; color: white;"><?php echo $annonces->Statut; ?></td>
                            <td style="background:mediumpurple; color: white;" class="text-right">1</td>
                            <td style="background:mediumpurple; color: white;" class="text-right"><?php echo $annonces->Prix . "€"; ?></td>
                            <td style="background:mediumpurple;" class="text-right"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><strong style="color: white;">Total</strong></td>
                            <td style="color: white;" class="text-right"><strong><?php echo $annonces->Prix . "€"; ?></strong></td>
                        </tr>
                    </tbody>

                </table>
            </div>
        </div>
        <div class="col mb-2">
            <div class="row">
                <div class="col-sm-12 col-md-6 text-right">
                    <a href=" {{url('/paiement')}} "><button class="btn btn-lg btn-block btn-outline-light text-uppercase">Continuer le paiement</button></a>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection