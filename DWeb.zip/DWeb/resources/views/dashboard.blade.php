@extends('layout')

@section('contenu')
    <br><br>

    
        <h3 style="font-size: 35px;" class="text-bold">Vos informations personnelles :</h3>
        <br>
        <p style="font-size: 20px; margin-left: 10px;" class="font-weight-normal">Nom : {{$user->name}}</p>
        <p style="font-size: 20px; margin-left: 10px;" class="font-weight-normal">Prénom : {{$user->prenom}}</p>
        <p style="font-size: 20px; margin-left: 10px;" class="font-weight-normal">Mail : {{$user->email}}</p>
        <p style="font-size: 20px; margin-left: 10px;" class="font-weight-normal">Naissance : {{$user->naissance}}</p>
        <p style="font-size: 20px; margin-left: 10px;" class="font-weight-normal">Solde : {{$user->solde}} €</p>

    <br><br>

@endsection