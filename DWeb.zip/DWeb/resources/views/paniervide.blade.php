@extends('layout')

@section('contenu')
<br><br><br><br>
<section style="background: mediumpurple;" class="jumbotron text-center">
    <div style="background: mediumpurple;" class="container">
        <h1 style="background: mediumpurple;" class="jumbotron-heading">Votre panier est vide...</h1>
     </div>
</section>

<div class="container mb-4">
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th style="color: white;" scope="col"> </th>
                            <th style="color: white;" scope="col">Nom du Jeu</th>
                            <th style="color: white;" scope="col">Stock</th>
                            <th style="color: white;" scope="col" class="text-center">Quantité</th>
                            <th style="color: white;" scope="col" class="text-right">Prix</th>
                            <th> </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="background:mediumpurple;"><img style="width: 20%;" src="" /> </td>
                            <td style="background:mediumpurple; color: white;">Aucun jeu</td>
                            <td style="background:mediumpurple;"></td>
                            <td style="background:mediumpurple; color: white; margin-right: 10%;" class="text-right">0</td>
                            <td style="background:mediumpurple; color: white;" class="text-right">0</td>
                            <td style="background:mediumpurple;" class="text-right"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><strong style="color: white;">Total</strong></td>
                            <td style="color: white;" class="text-right"><strong>0</strong></td>
                        </tr>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>

@endsection